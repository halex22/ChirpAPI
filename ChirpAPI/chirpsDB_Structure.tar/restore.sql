--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cinguettio;
--
-- Name: cinguettio; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE cinguettio WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE cinguettio OWNER TO postgres;

\connect cinguettio

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chirps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chirps (
    id integer NOT NULL,
    text character varying(140) NOT NULL,
    ext_url character varying(2083),
    creation_time timestamp without time zone DEFAULT now() NOT NULL,
    lat double precision,
    lng double precision
);


ALTER TABLE public.chirps OWNER TO postgres;

--
-- Name: chirps_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.chirps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chirps_id_seq OWNER TO postgres;

--
-- Name: chirps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.chirps_id_seq OWNED BY public.chirps.id;


--
-- Name: commets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commets (
    id integer NOT NULL,
    chirp_id integer NOT NULL,
    parent_id integer,
    text bit varying(140) NOT NULL,
    creation_date timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.commets OWNER TO postgres;

--
-- Name: commets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.commets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.commets_id_seq OWNER TO postgres;

--
-- Name: commets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.commets_id_seq OWNED BY public.commets.id;


--
-- Name: chirps id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chirps ALTER COLUMN id SET DEFAULT nextval('public.chirps_id_seq'::regclass);


--
-- Name: commets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commets ALTER COLUMN id SET DEFAULT nextval('public.commets_id_seq'::regclass);


--
-- Data for Name: chirps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chirps (id, text, ext_url, creation_time, lat, lng) FROM stdin;
\.
COPY public.chirps (id, text, ext_url, creation_time, lat, lng) FROM '$$PATH$$/4856.dat';

--
-- Data for Name: commets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commets (id, chirp_id, parent_id, text, creation_date) FROM stdin;
\.
COPY public.commets (id, chirp_id, parent_id, text, creation_date) FROM '$$PATH$$/4858.dat';

--
-- Name: chirps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.chirps_id_seq', 1, false);


--
-- Name: commets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commets_id_seq', 1, false);


--
-- Name: chirps chirp_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chirps
    ADD CONSTRAINT chirp_pk PRIMARY KEY (id);


--
-- Name: commets comment_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commets
    ADD CONSTRAINT comment_pk PRIMARY KEY (id);


--
-- Name: commets chirp_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commets
    ADD CONSTRAINT chirp_fk FOREIGN KEY (chirp_id) REFERENCES public.chirps(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: commets parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commets
    ADD CONSTRAINT parent_fk FOREIGN KEY (parent_id) REFERENCES public.commets(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- PostgreSQL database dump complete
--

